<!DOCTYPE html>
<html lang="en" dir="ltr">
  <?php include_once 'components/head.php'; ?>
  <body>
    <?php include_once 'components/header.php'; ?>
    <?php include_once 'components/nav.php'; ?>


    <main class="bg-lighter">
      <div class="container">
        <div class="sec news1">
          <h2 class="text-red news1">09.03.02 Информационные системы и технологии (ИФСТ)</h2>
          <div class="big_photo" style="background-image: url(imgs/ifst.jpg)"></div>

          <div class="row">
            <div class="col-12 col-md-8">
              <p class="text-grey">
                Уникальное сочетание знаний в области компьютерных технологий, программирования,  операционных систем, мультмедиа-технологий позволяет выпускникам стать самыми востребованными специалистами на рынке труда не только в России, но и за рубежом. Уже в ходе обучения студенты могут попробовать себя в коммерческих проектах по реализации программных систем и компьютерной графики в рамках молодежного бизнес-предприятия, действующего в международном образовательном центре СГТУ. Студенты кафедры участвуют в различных международных проектах и имеют возможность проходить международные стажировки.
                <br><br>
                В ходе обучения студенты изучают современные технологии программирования и управления программными проектами  в компаниях Neoflex, NetCracker, EPAM Systems и др.
<br><br>
                Наши выпускники становятся высококвалифицированными специалистами в этой быстро развивающейся отрасли, владеют теорией и практическими знаниями новейших методов и программных средств разработки программного обеспечения: (программирование на языках C, C#, JAVA, Perl, PHP, JSP, EJB, J2EE), разработки и управления базами данных MS SQL, Oracle, технологиями .NET, ASP, XML, Internet – технологиями, облачными и распределенными решениями, методами цифровой обработки видео- и аудиоинформации, а так же изучают все аспекты профессиональной работы с компьютерной графикой, разработки компьютерных игр.
                <br><br>
Выпускник может работать:
<br>
Директором по информационным технологиям<br>
Начальником АСУ и отделов информатизации<br>
Разработчиком мобильных решений<br>
Программистом (.NET, Java, Perl, PHP)<br>
Администратором и разработчиком баз данных (MS SQL, Oracle, MYSQL)<br>
Веб-программистом<br>
Тестировщиком программного обеспечения<br>
Разработчиком решений 1С
              </p>
              <div class="bottom"><a class="text-red" href="https://www.sstu.ru/obrazovanie/instituty/inpit/oop/informatsionnye-sistemy-i-tekhnologii-ifst">Подробнее</a></div>
            </div>

            <div class="col-12 col-md-4 contacts">
              <div class="row row-cols-4 row-cols-md-1">
                <div class="col profile">
                  <p class="name text-white">Профиль</p>
                  <p class="email text-white">информационные системы и технологии</p>
                </div>
                <div class="col profile">
                  <p class="name text-white">Очная форма обучения</p>
                  <p class="email text-white">4 года</p>

                  <p class="name text-white">Заочная форма обучения</p>
                  <p class="email text-white">5 лет</p>
                </div>
                <div class="col profile">
                  <p class="name text-white">Вступительные испытания</p>
                  <p class="email text-white">математика</p>
                  <p class="email text-white">русский язык</p>
                  <p class="email text-white">физика или информатика на выбор</p>
                </div>
                <div class="col profile">
                  <p class="name text-white">Выпускающая кафедра</p>
                  <p class="email text-white"><a href="cafedra.php" class="text-white">Прикладные информационные технологии</a></p>
                </div>
              </div>
            </div>
          </div>

          <div class="text-left text-red" style="margin-top: 15px; font-size: 13px">
             <a class="text-red" href="cafedra.php">Вернуться</a>
          </div>

        </div>
      </div>
    </main>

    <footer class="bg-red">
      <div class="container">
        <?php include_once 'components/footer.php'; ?>
      </div>
    </footer>
  </body>
</html>
