<div class="row bottom">
  <div class="col-12 col-md-6 col-lg-5">
    <p class="text-white">Институт прикладных информационных технологий</p>
    <p class="text-white">ул. Политехническая, д. 77. офис 413</p>
    <p class="text-white">+7 (8452) 99-87-17</p>
    <p class="text-white">+7 (8452) 99-87-16</p>
    <p class="text-white">© 1998-2021 Институт прикладных информационных технологий и коммуникаций</p>
  </div>
  <div class="col-12 col-md-3 col-lg-3">
    <div class="d-flex flex-column justify-content-between align-items-start">
      <p><a href="index.php" class="text-white">Главная</a></p>
      <p><a href="about.php" class="text-white">Об Институте</a></p>
      <p><a class="text-white">Абитуриенту</a></p>
      <p><a class="text-white">Карьера</a></p>
    </div>
  </div>
  <div class="col-12 col-md-3 col-lg-3">
    <div class="d-flex flex-column justify-content-between align-items-start">
      <p><a class="text-white">Ответы на вопросы</a></p>
      <p><a href="news.php" class="text-white">Новости</a></p>
      <p><a class="text-white">Контакты</a></p>
    </div>
  </div>
  <div class="col-12 col-lg-1">
    <div class="d-flex flex-row justify-content-end align-items-start icons">
      <a  class="text-white"><img src="imgs/vk.png" alt=""></a>
      <a  class="text-white"><img src="imgs/insta.png" alt=""></a>
      <a  class="text-white"><img src="imgs/youtube.png" alt=""></a>
      <a  class="text-white"><img src="imgs/facebook.png" alt=""></a>
    </div>
  </div>
</div>
