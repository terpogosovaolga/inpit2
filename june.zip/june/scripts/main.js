function toggleBlock(selector) {
  $(selector).toggle();
}
