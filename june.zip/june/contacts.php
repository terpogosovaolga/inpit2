<!DOCTYPE html>
<html lang="en" dir="ltr">
  <?php include_once 'components/head.php'; ?>
  <body>
    <?php include_once 'components/header.php'; ?>
    <?php include_once 'components/nav.php'; ?>

    <main class="bg-lighter">
        <div class="sec">
          <div class="container">
            <h2>Контакты</h2>
            <div class="row">
              <div class="col-12 col-md-8">
                  <div style="position:relative;overflow:hidden;width:100%;height:100%">
                    <a href="https://yandex.ru/maps/org/saratovskiy_gosudarstvenny_tekhnicheskiy_universitet_imeni_gagarina_yu_a_/1556557124/?utm_medium=mapframe&utm_source=maps" style="color:#eee;font-size:12px;position:absolute;top:0px;">Саратовский Государственный Технический университет имени Гагарина Ю.А.</a>
                    <a href="https://yandex.ru/maps/194/saratov/category/university_college/184106140/?utm_medium=mapframe&utm_source=maps" style="color:#BE2F21;font-size:12px;position:absolute;top:14px;">ВУЗ в Саратове</a>
                    <iframe src="https://yandex.ru/map-widget/v1/-/CCUa7-EGgB" width="100%" height="100%" frameborder="1" allowfullscreen="true" style="position:relative;"></iframe>
                  </div>
              </div>
              <div class="col-12 col-md-4 contacts">
                <h2 class="text-white">Контакты</h2>
                <div class="row row-cols-4 row-cols-md-1">
                  <div class="col profile">
                    <p class="name text-white">Кумова Светлана Валентиновна</p>
                    <p class="job text-white">Директор</p>

                    <p class="phone text-white">(8-452) 99-87-15</p>
                    <p class="email text-white">skumova@mail.ru</p>
                  </div>
                  <div class="col profile">
                    <p class="name text-white">Каликинская Елена Юрьевна</p>
                    <p class="job text-white">Заместитель директора по учебной работе</p>

                    <p class="phone text-white">(8-452) 99-87-17</p>
                    <p class="email text-white">kalikinskaya@sstu.ru</p>
                  </div>
                  <div class="col profile">
                    <p class="name text-white">Торопова Ольга Анатольевна</p>
                    <p class="job text-white">Заместитель директора по научной работе</p>

                    <p class="phone text-white">(8-452) 99-87-18</p>
                    <p class="email text-white">toropovaoa@inbox.ru</p>
                  </div>
                  <div class="col profile">
                    <p class="name text-white">Петрова Татьяна Юрьевна</p>
                    <p class="job text-white">Заместитель директора по воспитательной работе</p>

                    <p class="phone text-white">(8-452) 99-87-18</p>
                    <p class="email text-white">p-t-u@mail.ru</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <footer class="bg-red">
        <div class="container">
          <?php include_once 'components/footer.php'; ?>
        </div>
      </footer>
    </body>
  </html>
