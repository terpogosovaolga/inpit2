<!DOCTYPE html>
<html lang="en" dir="ltr">
  <?php include_once 'components/head.php'; ?>
  <body>
    <?php include_once 'components/header.php'; ?>
    <?php include_once 'components/nav.php'; ?>

    <main class="bg-lighter">
        <div class="sec">
          <div class="container">
            <h4>Поиск по вакансиям</h4>
            <div class="search form">
              <form class="" action="index.html" method="post">
                <div class="row">
                  <div class="col-10">
                    <input type="text" name="search" value="" class="form-control" placeholder="Поиск по вакансиям...">
                  </div>
                  <div class="col-2">
                    <input type="button" name="ready" value="Найти" class="btn bg-red text-white bg-red-hover" style="width: 100%">
                  </div>
                </div>
              </form>
            </div>
          </div>

            <div class="vacancies">
                <div class='container'>
                  <h2>Вакансии <i class="fas fa-sort-amount-down-alt text-red-hover" style="float: right" onclick="toggleBlock('div.filters')"></i></h2>
                </div>
                <div class="filters bg-white" style="display: none">
                  <div class="container">
                  <form class="" action="index.html" method="post">

                    <div class="row">
                      <div class="col-12 col-md-6 rowcol">
                        <h6>Компания:</h6>
                        <select class="form-control" name="company">
                          <option value="">Любая</option>
                          <option value="">Рубль-Бум</option>
                          <option value="">СГТУ</option>
                          <option value="">Сибинтек</option>
                        </select>
                      </div>
                      <div class="col-12 col-md-6 rowcol">
                        <h6>Вакансия:</h6>
                        <select class="form-control" name="company">
                          <option value="">Любая</option>
                          <option value="">Разработчик 1С</option>
                          <option value="">Разработчик Java</option>
                          <option value="">Front-end Разработчик</option>
                        </select>
                      </div>
                      <div class="col-12 col-md-6 rowcol">
                        <h6>Опыт:</h6>
                        <select class="form-control" name="company">
                          <option value="">Любой</option>
                          <option value="">Без опыта</option>
                          <option value="">1-3 года</option>
                          <option value="">3-6 лет</option>
                          <option value="">от 6 лет</option>
                        </select>
                      </div>
                      <div class="col-12 col-md-6 rowcol">
                        <h6>График:</h6>
                        <select class="form-control" name="company">
                          <option value="">Любой</option>
                          <option value="">Полный день</option>
                          <option value="">Неполный день</option>
                          <option value="">Гибкий график</option>
                          <option value="">Дистанционно</option>
                        </select>
                      </div>
                    </div>

                    <div class="text-center rowcol">
                      <button type="submit" name="button" class="btn bg-red text-white">Готово</button>
                      <button type="submit" name="button" class="btn bg-white text-red" style="border: 1px solid var(--red)">Сбросить фильтры</button>
                    </div>

                  </form>
                </div>
                </div>
                <div class="container">
                <div class="vacancy bg-white">
                  <a href="vacancy.php"><h3>
                    <img src="imgs/1b.svg" alt="" height="85px">
                    Разработчик 1С
                  </h3></a>
                  <div class="bottom">
                    <div class="d-flex flex-row justify-content-around align-center">
                      <a href="#" class="company text-red"><i class="fas fa-briefcase"></i> Рубль Бум</a>
                      <span><i class="fas fa-ruble-sign"></i> От 15 000 р.</span>
                      <span><i class="fas fa-calendar"></i> Полный рабочий день</span>
                    </div>
                  </div>
                </div>

                <div class="vacancy bg-white">
                  <a href="vacancy.php"><h3>
                    <img src="imgs/1b.svg" alt="" height="85px">
                    Разработчик 1С
                  </h3></a>
                  <div class="bottom">
                    <div class="d-flex flex-row justify-content-around align-center">
                      <a href="#" class="company text-red"><i class="fas fa-briefcase"></i> Рубль Бум</a>
                      <span><i class="fas fa-ruble-sign"></i> От 15 000 р.</span>
                      <span><i class="fas fa-calendar"></i> Полный рабочий день</span>
                    </div>
                  </div>
                </div>

                <div class="vacancy bg-white">
                  <a href="vacancy.php"><h3>
                    <img src="imgs/1b.svg" alt="" height="85px">
                    Разработчик 1С
                  </h3></a>
                  <div class="bottom">
                    <div class="d-flex flex-row justify-content-around align-center">
                      <a href="#" class="company text-red"><i class="fas fa-briefcase"></i> Рубль Бум</a>
                      <span><i class="fas fa-ruble-sign"></i> От 15 000 р.</span>
                      <span><i class="fas fa-calendar"></i> Полный рабочий день</span>
                    </div>
                  </div>
                </div>

                <div class="vacancy bg-white">
                  <a href="vacancy.php"><h3>
                    <img src="imgs/1b.svg" alt="" height="85px">
                    Разработчик 1С
                  </h3></a>
                  <div class="bottom">
                    <div class="d-flex flex-row justify-content-around align-center">
                      <a href="#" class="company text-red"><i class="fas fa-briefcase"></i> Рубль Бум</a>
                      <span><i class="fas fa-ruble-sign"></i> От 15 000 р.</span>
                      <span><i class="fas fa-calendar"></i> Полный рабочий день</span>
                    </div>
                  </div>
                </div>

                <div class="vacancy bg-white">
                  <a href="vacancy.php"><h3>
                    <img src="imgs/1b.svg" alt="" height="85px">
                    Разработчик 1С
                  </h3></a>
                  <div class="bottom">
                    <div class="d-flex flex-row justify-content-around align-center">
                      <a href="#" class="company text-red"><i class="fas fa-briefcase"></i> Рубль Бум</a>
                      <span><i class="fas fa-ruble-sign"></i> От 15 000 р.</span>
                      <span><i class="fas fa-calendar"></i> Полный рабочий день</span>
                    </div>
                  </div>
                </div>
              </div>

              <div class="text-right pages m-3">
                <div class="container">
                    <span>
                    <i class="fas fa-chevron-left text-red"></i> <span class="text-red" style="font-weight:700">1</span> <span class="text-grey">из 14</span> <i class="fas fa-chevron-right text-red"></i>
                  </span>
                </div>
              </div>
            </div>


          </div>
        </div>
    </main>

    <footer class="bg-red">
      <div class="container">
        <?php include_once 'components/footer.php'; ?>
      </div>
    </footer>
  </body>
</html>
