<!DOCTYPE html>
<html lang="en" dir="ltr">
  <?php include_once 'components/head.php'; ?>
  <body>
    <?php include_once 'components/header.php'; ?>
    <?php include_once 'components/nav.php'; ?>


    <main class="bg-lighter">
      <div class="sec">
        <div class="container">
          <h2>Кафедра «Прикладные информационные технологии» (ПИТ)</h2>
          <div class="row">
            <div class="col-12 col-md-8">
              <p class="text-grey">
                Кафедра Прикладных информационных технологий (ПИТ) была создана в 2002 году с целью реализации учебных программ, соответствующих как российским, так и международным стандартам.
                <br><br>
                В учебном процессе кафедра ПИТ специализируется на технологиях профессионального программирования (C, C#, Java, Perl, PHP), мобильных технологиях, облачных вычислениях, создании приложений виртуальной и дополненной реальности, распределенных приложений и базах данных, технологиях разработки компьютерных игр, Интернет-технологиях.
                <br><br>
                На кафедре работают представители ведущих ИКТ-компаний: NetCracker, Неофлекс, СибИНТЕК, Грид Динамикс, Артезио, Белл Интегратор и др. Преподаватели кафедры имеют статусы авторизованных тренеров Microsoft, Autodesk, специалистов Hewlett-Packard, Adobe, EMC, Oracle, что позволяет вести учебный процесс на высоком профессиональном уровне.
              </p>
              <div class="bottom"><a class="text-red" href="https://www.sstu.ru/obrazovanie/instituty/inpit/struktura/pit/">Подробнее</a></div>
            </div>
            <div class="col-12 col-md-4 contacts">
              <h2 class="text-white">Контакты</h2>
              <div class="row row-cols-4 row-cols-md-1">
                <div class="col profile">
                  <p class="name text-white">Торопова Ольга Анатольевна</p>
                  <p class="job text-white">Заведующая кафедрой, кандидат технических наук, доцент</p>

                  <p class="phone text-white">(8-452) 99-87-18</p>
                  <p class="email text-white">toropovaoa@inbox.ru</p>
                </div>
                <div class="col profile">
                  <p class="email text-white"><i class="fas fa-map-marker-alt"></i> Корпус 1, комната 424</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="sec cafs bg-white">
        <div class="container">
          <h2 style="margin-top: 40px">Направления кафедры ПИТ</h2>
          <div class="row">
            <h5 style="margin-top: 20px">Бакалавриат</h5>
            <div class="col-12 col-md-6">
              <div class="caf">
                <h4 class="text-red">ИФСТ</h4>
                <!-- <span class="level">бакалавриат</span> -->
                <p>Профиль "Информационные системы и технологии"</p>

                <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                  <span class="text-red ball">
                    Проходной бал 2020: 200
                  </span>
                  <div class="d-flex flex-column align-end justify-content-end">
                  <a href="direction.php" class="text-red more">Подробнее</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-6">
              <div class="caf">
                <h4 class="text-red">ИФСТ</h4>
                <!-- <span class="level">бакалавриат</span> -->
                <p>Профиль "Информационные технологии медиаиндустрии"</p>

                <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                  <span class="text-red ball">
                    Проходной бал 2020: 200
                  </span>
                  <div class="d-flex flex-column align-end justify-content-end">
                  <a href="#" class="text-red  more">Подробнее</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-6" style="margin-top: 20px">
              <div class="caf">
                <h4 class="text-red">ПИНФ</h4>
                <!-- <span class="level">бакалавриат</span> -->
                <p>Профиль "Прикладная информатика в информационной среде"</p>

                  <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                    <span class="text-red ball">
                      Проходной бал 2020: 200
                    </span>
                      <div class="d-flex flex-column align-end justify-content-end">
                      <a href="#" class="text-red more">Подробнее</a>
                      </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row" style="margin-top: 40px">
              <h5>Магистратура</h5>
              <div class="col-12 col-md-6">
                <div class="caf">
                  <h4 class="text-red">мИФСТ</h4>
                  <!-- <span class="level">бакалавриат</span> -->
                  <p>Профиль "Информационные системы и технологии промышленного программирования"</p>

                    <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                      <span class="text-red ball">
                        Проходной бал 2020: 200
                      </span>
                        <div class="d-flex flex-column align-end justify-content-end">
                        <a href="#" class="text-red more">Подробнее</a>
                        </div>
                    </div>
                  </div>
              </div>
              <div class="col-12 col-md-6">
                <div class="caf">
                  <h4 class="text-red">мПИНФ</h4>
                  <!-- <span class="level">бакалавриат</span> -->
                  <p>Профиль "Прикладные Интернет-технологии"</p>

                    <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                      <span class="text-red ball">
                        Проходной бал 2020: 200
                      </span>
                        <div class="d-flex flex-column align-end justify-content-end">
                        <a href="#" class="text-red more">Подробнее</a>
                        </div>
                    </div>
                  </div>
              </div>
            </div>

          </div>
        </div>
    </main>

    <footer class="bg-red">
      <div class="container">
        <?php include_once 'components/footer.php'; ?>
      </div>
    </footer>
  </body>
</html>
