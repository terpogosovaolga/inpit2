<!DOCTYPE html>
<html lang="en" dir="ltr">
  <?php include_once 'components/head.php'; ?>
  <body>
    <?php include_once 'components/header.php'; ?>
    <?php include_once 'components/nav.php'; ?>

    <main class="bg-lighter">
        <div class="sec">
          <div class="container">
            <h2>Абитуриенту</h2>
            <p class="text-grey">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
          </div>
        </div>

            <div class="sec cafs bg-white">
              <div class="container">
                <h2 style="margin-top: 40px">Направления ИнПИТ</h2>
                <div class="row">
                  <h5 style="margin-top: 20px">Бакалавриат</h5>
                  <div class="col-12 col-md-6">
                    <div class="caf">
                      <h4 class="text-red">ИФСТ</h4>
                      <p>09.04.02 Информационные системы и технологии</p>
                      <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                        <span class="text-red ball">
                          Проходной бал 2020: 200
                        </span>
                        <div class="d-flex flex-column align-end justify-content-end">
                        <a href="direction.php" class="text-red more">Подробнее</a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12 col-md-6">
                    <div class="caf">
                      <h4 class="text-red">ПИНФ</h4>
                      <!-- <span class="level">бакалавриат</span> -->
                      <p>09.03.03 Прикладная информатика</p>

                      <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                        <span class="text-red ball">
                          Проходной бал 2020: 200
                        </span>
                        <div class="d-flex flex-column align-end justify-content-end">
                        <a href="#" class="text-red  more">Подробнее</a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12 col-md-6" style="margin-top: 20px">
                    <div class="caf">
                      <h4 class="text-red">ИВЧТ</h4>
                      <!-- <span class="level">бакалавриат</span> -->
                      <p> 09.03.01 Информатика и вычислительная техника</p>

                        <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                          <span class="text-red ball">
                            Проходной бал 2020: 200
                          </span>
                            <div class="d-flex flex-column align-end justify-content-end">
                            <a href="#" class="text-red more">Подробнее</a>
                            </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-12 col-md-6" style="margin-top: 20px">
                      <div class="caf">
                        <h4 class="text-red">ПИНЖ</h4>
                        <!-- <span class="level">бакалавриат</span> -->
                        <p>09.03.02 Прикладная инженерия</p>

                          <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                            <span class="text-red ball">
                              Проходной бал 2020: 200
                            </span>
                              <div class="d-flex flex-column align-end justify-content-end">
                              <a href="#" class="text-red more">Подробнее</a>
                              </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-12 col-md-6" style="margin-top: 20px">
                        <div class="caf">
                          <h4 class="text-red">ТЛВД</h4>
                          <!-- <span class="level">бакалавриат</span> -->
                          <p>42.03.04 Телевидение</p>

                            <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                              <span class="text-red ball">
                                Проходной бал 2020: 200
                              </span>
                                <div class="d-flex flex-column align-end justify-content-end">
                                <a href="#" class="text-red more">Подробнее</a>
                                </div>
                            </div>
                          </div>
                        </div>
                        <div class="col-12 col-md-6" style="margin-top: 20px">
                          <div class="caf">
                            <h4 class="text-red">ДИЗН</h4>
                            <!-- <span class="level">бакалавриат</span> -->
                            <p>54.03.01 Дизайн</p>

                              <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                                <span class="text-red ball">
                                  Проходной бал 2020: 200
                                </span>
                                  <div class="d-flex flex-column align-end justify-content-end">
                                  <a href="#" class="text-red more">Подробнее</a>
                                  </div>
                              </div>
                            </div>
                          </div>
                          <div class="col-12 col-md-6" style="margin-top: 20px">
                            <div class="caf">
                              <h4 class="text-red">РКЛМ</h4>
                              <!-- <span class="level">бакалавриат</span> -->
                              <p>42.03.01 Реклама и связи с общественностью</p>

                                <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                                  <span class="text-red ball">
                                    Проходной бал 2020: 200
                                  </span>
                                    <div class="d-flex flex-column align-end justify-content-end">
                                    <a href="#" class="text-red more">Подробнее</a>
                                    </div>
                                </div>
                              </div>
                            </div>
                  </div>
                  <div class="row" style="margin-top: 40px">
                    <h5>Магистратура</h5>
                    <div class="col-12 col-md-6" style="margin-top: 20px">
                      <div class="caf">
                        <h4 class="text-red">мИФСТ</h4>
                        <!-- <span class="level">бакалавриат</span> -->
                        <p>09.04.02 Информационные системы и технологии промышленного программирования</p>

                          <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                            <span class="text-red ball">
                              Проходной бал 2020: 200
                            </span>
                              <div class="d-flex flex-column align-end justify-content-end">
                              <a href="#" class="text-red more">Подробнее</a>
                              </div>
                          </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6" style="margin-top: 20px">
                      <div class="caf">
                        <h4 class="text-red">мИВЧТ</h4>
                        <!-- <span class="level">бакалавриат</span> -->
                        <p>09.04.01 Информатика и вычислительная техника</p>

                          <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                            <span class="text-red ball">
                              Проходной бал 2020: 200
                            </span>
                              <div class="d-flex flex-column align-end justify-content-end">
                              <a href="#" class="text-red more">Подробнее</a>
                              </div>
                          </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6" style="margin-top: 20px">
                      <div class="caf">
                        <h4 class="text-red">мПИНФ</h4>
                        <!-- <span class="level">бакалавриат</span> -->
                        <p>09.04.03 Прикладная информатика</p>

                          <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                            <span class="text-red ball">
                              Проходной бал 2020: 200
                            </span>
                              <div class="d-flex flex-column align-end justify-content-end">
                              <a href="#" class="text-red more">Подробнее</a>
                              </div>
                          </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6" style="margin-top: 20px">
                      <div class="caf">
                        <h4 class="text-red">мПИНЖ</h4>
                        <!-- <span class="level">бакалавриат</span> -->
                        <p>09.04.04 Программная инженерия</p>

                          <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                            <span class="text-red ball">
                              Проходной бал 2020: 200
                            </span>
                              <div class="d-flex flex-column align-end justify-content-end">
                              <a href="#" class="text-red more">Подробнее</a>
                              </div>
                          </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6" style="margin-top: 20px">
                      <div class="caf">
                        <h4 class="text-red">мРКЛМ</h4>
                        <!-- <span class="level">бакалавриат</span> -->
                        <p>42.04.01 Реклама и связи с общественностью</p>

                          <div class="d-flex justify-content-between align-end bottom" style="width: 100%">
                            <span class="text-red ball">
                              Проходной бал 2020: 200
                            </span>
                              <div class="d-flex flex-column align-end justify-content-end">
                              <a href="#" class="text-red more">Подробнее</a>
                              </div>
                          </div>
                        </div>
                    </div>
                  </div>
                </div>

              </div>
              <a href="https://www.sstu.ru/abiturientu/">
                <div class="container">
                  <button type="button" name="button" class="btn bg-red text-white moreab">ПОДРОБНЕЕ О ПОСТУПЛЕНИИ</button>
              </div>
            </a>
    </main>
    <footer class="bg-red">
      <div class="container">
        <?php include_once 'components/footer.php'; ?>
      </div>
    </footer>
  </body>
</html>
