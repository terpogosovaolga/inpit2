<!DOCTYPE html>
<html lang="en" dir="ltr">
  <?php include_once 'components/head.php'; ?>
  <body>
    <?php include_once 'components/header.php'; ?>
    <?php include_once 'components/nav.php'; ?>

    <main class="bg-lighter">
        <div class="sec">
          <div class="container">


            <div class="row">
              <div class="col-12 col-md-9 bg-white">
                <div class="vac">
                <div class="header">
                  <div class="d-flex flex-row justify-content-between align-center">
                    <div>
                      <h2>1С Разработчик</h2>
                      <p class="info text-red">3-6 лет, полная занятость, полный рабочий день</p>
                      <p class="money text-red">от 25 000 р.</p>
                    </div>
                    <div>
                      <img src="imgs/exactpro.svg" alt="" height="120px">
                    </div>
                  </div>
                </div>
                <div class="infoblock">
                  <h5>Обязанности</h5>
                  <p>Ничего не делать</p>
                </div>
                <div class="infoblock">
                  <h5>Требования</h5>
                    <ul>
                      <li>Быть красивым</li>
                      <li>Быть трудолюбивым</li>
                      <li>Быть красивым</li>
                      <li>Быть трудолюбивым</li>
                      <li>Быть красивым</li>
                      <li>Быть трудолюбивым</li>
                    </ul>
                </div>
                <div class="infoblock">
                  <h5>Условия</h5>
                    <ul>
                      <li>Вас будут любить</li>
                      <li>Вас будут кормить</li>
                    </ul>
                </div>

                <div class="bottom" style="margin-top: 20px">
                  <div class="d-flex flex-row justify-content-between align-center">
                    <span class="text-red">29.06.2021</span>
                    <span>Просмотров: <span class="text-red">100</span></span>
                  </div>
                </div>
              </div>
              </div>
              <div class="col-12 col-md-3">
                <div class="contacts" style="height: 100%">
                  <h2 class="text-white">Контакты</h2>
                  <div class="row row-cols-4 row-cols-md-1">
                    <div class="col profile" style="border-bottom: 1px solid white; padding-bottom: 25px;">
                      <p class="name text-white">Иванов Иван Иванович</p>
                      <p class="job text-white">Контактное лицо</p>
                      <p class="phone text-white">(8-452) 99-87-15</p>
                      <p class="email text-white">ivanov@mail.ru</p>
                    </div>
                    <div class="col profile">
                      <p class="name text-white">Компания <span style="font-weight: 600">ExactPro</span></p>
                      <p class="job text-white"><a class="text-white" style="font-weight: 600" href="https://yandex.ru/maps/org/ekzaktpro/1610526369/?ll=45.999744%2C51.534137&mode=search&sll=46.034158%2C51.533103&source=wizgeo&sspn=1.617737%2C0.585848&text=exactpro&utm_medium=maps-desktop&utm_source=serp&z=13.92">
                        <i class="fas fa-map-marker-alt"></i> г. Саратов, Рабочая, 145</a>
                      </p>

                      <p class="phone text-white"><a class="text-white" href="https://exactpro.com">https://exactpro.com</a></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <a href="career.php" class="text-red" style="font-size: 14px"><i class="fas fa-chevron-left"></i> К вакансиям</a>
          </div>
        </div>
    </main>

    <footer class="bg-red">
      <div class="container">
        <?php include_once 'components/footer.php'; ?>
      </div>
    </footer>
  </body>
</html>
